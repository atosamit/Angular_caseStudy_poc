export const labelConstants =
// grid and list view tags
    [{
        
        CXTower: "CX Tower",
        CXTech: "CX Tech ",
        Publishedon:"Published on",
        Comments:" 11 Comments",
        ShareonLinkedIn:"Share on LinkedIn",
        ShareviaEmail:"Share via Email",
        CloseDiaBox:"Close",
        Previousbtn:"Previous",
        Nextbtn:"Next"
    },
    {
        Searchbtn:"Search",
        Placeholder:"Search by keyword, Name, Domain, date etc"
    },
    {
        Errormsg:" Displaying a message because the screen size is either less than 300px or greater than 2570px."
    }
]