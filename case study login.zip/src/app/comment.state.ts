
export interface CommentState {
    comments: string[];
  }