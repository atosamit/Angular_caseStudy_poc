// define a state
export const initialState={
    counter:5
}