import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public showData: any; // To store the data from the API
  public showImage!: string; // To store the image URL

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const apiURL = 'https://api.tvmaze.com/shows/1'; // Your API endpoint URL

    // Make an HTTP GET request to the TVmaze API
    this.http.get(apiURL).subscribe((data: any) => {
      this.showData = data; // Store the data in showData
      this.showImage = data.image.medium; // Store the image URL
    });
  }



  // ................................
  tvapp:any=[
    {list1:"Shows", list2:"People"},
 
  ]
  tvapp1:any=[
    {list11:"HOME", list22:"SHOWS", list33:"/"}
  ]
}
