import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    // Check if the user is authenticated (you need to implement this logic)
    const isAuth = // Implement your authentication check logic here;
    
    if (isAuth) {
      return true; // User is authenticated, allow access to the route
    } else {
      this.router.navigate(['/login']); // User is not authenticated, redirect to the login page
      return false;
    }
  }
}
