$(function()){
    alert("KGKJH");
}